This is a proof of the soundness of Featherweight Java (Atsushi Igarashi,
Benjamin Pierce and Philip Wadler) in the Twelf logical Framework.
It was developed by Stephanie Weirich <sweirich@cis.upenn.edu> and
Geoffrey Washburn <geoffw@cis.upenn.edu>.
