This directory should contain compiled theory files and documentation (in
the form of .vo and .pdf files).  Otherwise, use the provided Makefile to
build everything.
